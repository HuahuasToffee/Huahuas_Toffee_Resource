When installing the following mods, you can choose only one of the three options. Please don't install all of them. 

001_ALL-Capon: All playable bishops in the game are replaced with Hans. Note that in the "Divine Messenger" mission, the original character has limitations on its skills and actions.
002_ALL-GodWin: All playable bishops in the game are replaced with Godwin. Note that in the "Divine Messenger" mission, the original character has limitations on its skills and actions.
003_Capon&GodWin: All playable bishops in the game are replaced with Hans, and in the "Divine Messenger" mission, the character is still Godwin. Note that in the "Divine Messenger" mission, the original character has limitations on its skills and actions.